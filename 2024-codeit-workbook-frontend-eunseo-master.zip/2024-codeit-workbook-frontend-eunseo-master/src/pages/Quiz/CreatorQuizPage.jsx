import QuizSolveInterface from '../../features/quiz/components/QuizSolveInterface';

const QuizSolvePage = () => {
    return <QuizSolveInterface />;
};

export default QuizSolvePage;