export const SEARCH_TYPE = {
  COURSE: 'course',
  PROFESSOR: 'professor',
  UNIVERSITY: 'university'
};

export const RATING_MAX = 5;